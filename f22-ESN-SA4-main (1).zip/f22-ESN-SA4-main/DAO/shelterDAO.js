const Shelter = require('../models/Shelter');

class ShelterDAO{

    constructor(mode) {
        if (mode == 'api'){
            this.db = Shelter.APIShelter;
        }
        else {
            this.db = Shelter.Shelter;
        }
    }

    async create(creator, address, maxCapacity, foodProvided, medicineProvided){
        var ifFood = false;
        var ifMedicine = false;

        if (foodProvided.toLowerCase() == 'true'){
            ifFood = true;
        }

        if (medicineProvided.toLowerCase() == 'true'){
            ifMedicine = true;
        }

        return await this.db.create({
            address: address,
            maxCapacity: Number(maxCapacity),
            curCapacity: 0,
            foodProvided: ifFood,
            medicineProvided: ifMedicine,
            creator: creator
            // visitors: new Array()
        });
    }

    async getAll(){
        return this.db.find({});
    }

    async joinShelter(address, cur){
        return this.db.updateOne({address: address}, {$set: {curCapacity: cur}})
    }

    async leaveShelter(address, cur){
        return this.db.updateOne({address: address}, {$set: {curCapacity: cur}})
    }

    async deleteShelter(address){
        return this.db.deleteOne({address: address});
    }

    async checkCapacity(address){
        return this.db.find({address: address}, {curCapacity: 1, maxCapacity: 1})
    }

    async changeUsername(username, formerUsername){
        return this.db.updateMany({creator: formerUsername}, {$set: {creator: username}})
    }
}

module.exports = ShelterDAO;
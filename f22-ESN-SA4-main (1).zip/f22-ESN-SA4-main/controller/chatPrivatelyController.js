const MessageDBs = require('../models/Message');
const url = require("url");
const {query} = require("express");
const MessageDAO = require('../DAO/messageDAO');
const UserDAO = require('../DAO/userDAO')
const Message = require('../models/Message');
const e = require('express');
class chatPrivatelyController{


    async privateChat_get(req, res) {
        var info = url.parse(req.url,true).query;
        let messageDAO ;
        if (global.measureMode){
            messageDAO = new MessageDAO("measure");
        }else if (req.body.testing == "true"){
            messageDAO = new MessageDAO("api");
        
        }else{
            messageDAO = new MessageDAO("normal");
            
        }

        var sender = info.sender;
        var receiver = info.receiver;
        // just for integration testing
        if (sender== null &&  receiver == null) {
            sender = req.body.sender;
            receiver = req.body.receiver;
        }
       
        messageDAO.loadPrivateMessage(sender, receiver).then((result)=>{
            messageDAO.updateIfRead(sender, receiver);
            // messageDAO.updateIfRead(info.sender, info.receiver).then((re)=>{
            // console.log(re)
            // })
            res.status(200).json({msglist: result});
        }).catch((err)=>{
            console.error(err.message);
            res.status(500).json("server error retrieving private msg list");
            //
        })
    }

    async updateIfread_get(req, res) {
        var info = url.parse(req.url,true).query;
        let messageDAO ;
        
        if (global.measureMode){
            messageDAO = new MessageDAO("measure")
        }else if (req.body.testing == "true"){
            messageDAO = new MessageDAO("api")
        }else{
            messageDAO = new MessageDAO("normal")
        }
   
        // console.log(info.sender, info.receiver)
        messageDAO.updateIfRead(info.sender, info.receiver).then((result)=>{
            res.status(200).json({msglist: result});
        })
        // .catch((err)=>{
        //     console.error(err.message);
        //     res.status(500).json("server error retrieving private msg list");
        // })
    }

    async privateChatSocket_get(req, res){
        
   
        userDAO.getSocketID(req.body.username).then((result)=>{
            res.status(200).json({user: result});
        })
        // .catch((err)=>{
        //     console.error(err.message);
        //     res.status(500).json("server error retrieving socket set");
        // })
    }

    async privateChat_post(req, res) {
        
        let messageDAO ;
        
        if (global.measureMode){
            messageDAO = new MessageDAO("measure")
        }else if (req.body.testing == "true"){
            messageDAO = new MessageDAO("api")
        }else{
            messageDAO = new MessageDAO("normal")
        }
   
        let user_map = req.app.get('userMap');

        messageDAO.create(
            req.body.message,
            req.body.sender,
            req.body.receiver,
            req.body.type,
            req.body.time,
            req.body.status,
            false).then((result)=>{
                var receiver = req.body.receiver;
                let global_io = req.app.get('io');
                if (user_map.has(receiver)) {
                    var toId = user_map.get(receiver)
                    console.log("send to", receiver, toId);
                    // var toSocket = _.findWhere(global_io.sockets.sockets, {id: toId});
                    global_io.to(toId).emit("privateMsg", result);
                }
                else{
                    console.log(user_map.has(receiver));
                    console.log("no map");
                }
                
                // if (user_map.has(req.body.receiver)) {
                //     user_map.get(req.body.sender).to(user_map.get(req.body.receiver).id).emit("privateMsg", result)
                // }
            res.status(201).json({ret: result});
        })
        // .catch(function(err){
            
        //     console.log(err.message);
        //     res.status(500).json("server error posting msg");
        // })
    }
}

let chat_privately_controller = new chatPrivatelyController();      
module.exports = {
    privateChat_get: chat_privately_controller.privateChat_get,
    privateChat_post: chat_privately_controller.privateChat_post,
    updateIfread_get: chat_privately_controller.updateIfread_get,
    privateChatSocket_get: chat_privately_controller.privateChatSocket_get
};
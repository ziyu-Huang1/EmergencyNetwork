// var publicsocket=io({
//     query:{
//         users: 
//     }
// })


var socket=null

function createConnecttion(user){
    // socket =  io({
    //     query:{
    //         user: user
    //     }
    // })
    // console.log("create a new socket"+socket.id);
    // return socket
}

function getSocket(user){

    // if(window.socket === null){
    //     console.log("no valid socket")
    // }
    // console.log("success get socket"+window.socket)
    // return window.socket

    // var data = {
    //     'username':user
    // }

    // $.ajax({
    //     contentType: 'application/json; charset=UTF-8',
    //     data: JSON.stringify(data),
    //     type: 'put',
    //     url: '/messages/private/socket',
    //     dataType: 'json',
    //     success: function (res) {
    //         console.log("get socket successfully"+ typeof res.user);
    //         console.log("get socket successfy"+ res.user);
    //     },
    //     error: function (jqXHR, status, err) {
    //         console.log("get socket error");
    //     }
    // })

}



const errorText={
    joinInCommunityErrors:{
        userNameError:"username should be ... long",
        userBanned:"Username banned",
        wrongPassword:"Wrong Password",
        userNotFound:"No such user found",
        serverError:"Server error",
        userInactive: "This user is inactive"
    },
    joinInCommunityInform:{
        userExist:"User already exists"
    },
    measurePerformanceInfo:{
        systemUnavaliable: "The system is meauring performance and unavalible for now. Please try agiain later"
    }
}

module.exports=errorText;